
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import entity.Computer;

public class BuildYourPcClient {
    static Client client = ClientBuilder.newClient();
    static WebTarget target = client.target("http://localhost:8080/BuildYourComputerProject/Webresources/entity.computer");
    public static void main(String[] args) {
        Computer computer = new Computer("hej", "då", "re", "asd", "kk", "ar","kuk",198);
        computer.setId(1L);
        updateComputer(computer);
        System.out.println(computer);
        getAllComputers();
        System.out.println("Här tar vi bort");
        deleteComputer("12345");
        getAllComputers();
        System.out.println("testar find");
        findComputerById("1L");
    }
    
    public static void createComputer(Computer c) {
        target.request().post(Entity.json(c));
    }
    
     public static void updateComputer(Computer c){

        target.request().put(Entity.json(c));

    }
    public static Computer[] getAllComputers(){

        Computer[] computers = target.request().get(Computer[].class);

        for (Computer comp : computers) {
            System.out.println(computers);

        }

        return computers;
    }

    public static void deleteComputer(String id){
    target.path(id).request().delete();


    }
    public static Computer findComputerById(String id){
        Computer comp = target.path(id).request().get(Computer.class);
        System.out.println(comp);
        return comp;
    }
}
